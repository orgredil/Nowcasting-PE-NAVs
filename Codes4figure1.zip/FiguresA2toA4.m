function [figReplaced, feasibleOLSest] = FiguresA2toA4(FundOutput,otherOutput,figNameIdx,strSize,replaceFig,figPathOut)
% filecorename='SimFundsBase100_profAlphBet';
% f=91;
figReplaced=0;

TrueAlpha= otherOutput.TrueAlfa;
TrueBeta = otherOutput.TrueBeta;

%%
prof_alpha_range = FundOutput.profiling.alpha_range;
prof_beta_range  = FundOutput.profiling.beta_range;
norm_LogProfile  = FundOutput.profiling.LlhdNrom;
norm_LogProfile2 = FundOutput.profiling.Penalty;
penalLogProfile  = FundOutput.profiling.LlhdPen-min(min(FundOutput.profiling.LlhdPen));


CFs  = [-otherOutput.CFandVhatXt0(:,1) otherOutput.CFandVhatXt0(:,2)];
CFsX0= CFs; CFsX0(CFs==0)=NaN;
T0   = FundOutput.Details.T0;
T    = FundOutput.Details.TT;
tt = (1:T)';

repNAV = exp(otherOutput.yFund(1:T,2));
Values = [repNAV otherOutput.CFandVhatXt0(:,3) FundOutput.Vt otherOutput.TrueVs]; 
Values(end,:)=nan;

cumsumSE =  cumsum((Values(:,2:end-1)./Values(:,end)-1).^2);
RMSEs    = (cumsumSE(13:end,:)-cumsumSE(1:end-12,:)).^(0.5);
QRMSEs   =  RMSEs;
QRMSEs(isnan(repNAV(13:end)),:) = nan;
QRMSEsMQ = [nan(12,2); QRMSEs(8:end,:); QRMSEs(1:7,:)];

Ms   = [otherOutput.M0(1:T) otherOutput.M_i15(1:T) otherOutput.TrueM(1:T)]; 

CumRets  = [cumsum(otherOutput.rmt) cumsum(FundOutput.Details.Naive_rt) ...
            cumsum(FundOutput.rt_kf) cumsum(FundOutput.rt) cumsum(log(1+otherOutput.TrueRs))]; 
CumRetsQ = CumRets(~isnan(repNAV),:);
Qrets    = CumRetsQ(2:end,:)- CumRetsQ(1:end-1,:);

OLSnaive = fitlm(exp(otherOutput.rmt(1:T0)),exp(FundOutput.Details.Naive_rt(1:T0)));    
OLStruR  = fitlm(exp(otherOutput.rmt(1:T0))-1,otherOutput.TrueRs(1:T0));
QAR1     = fitlm(exp(Qrets(1:end-1,1))-1,exp(Qrets(2:end,1))-1);

QOLScapm  =fitlm(exp(Qrets(1:floor(T0/13),1))-1,exp(Qrets(1:floor(T0/13),2))-1);    
QOLScapmDL=fitlm(exp([Qrets(1:floor(T0/13)-1,1) Qrets(2:floor(T0/13),1)])-1,exp(Qrets(2:floor(T0/13),2))-1);
QOLScapmR1=fitlm(exp(Qrets(2:floor(T0/13),1))-1,QAR1.Residuals.Raw(1:floor(T0/13)-1));    

feasibleOLSest.alpha=sort([OLSnaive.Coefficients{1,1}*13 QOLScapm.Coefficients{1,1}*4 QOLScapmDL.Coefficients{1,1}*4 QOLScapmR1.Coefficients{1,1}*4]);
feasibleOLSest.beta=sort([OLSnaive.Coefficients{2,1} QOLScapm.Coefficients{2,1} QOLScapmDL.Coefficients{2,1}+QOLScapmDL.Coefficients{3,1} QOLScapmR1.Coefficients{2,1}]);

%% Figure A2
%for time series charts
figure
x0=560;y0=50;
width=800; height=width/otherOutput.FigA2Alayout.aspect;
set(gcf,'units','points','position',[x0,y0,width,height])
xLim=otherOutput.FigA2Alayout.xLim;
xTic=otherOutput.FigA2Alayout.xTic;
grid on
hold on
yyaxis left
ylim(otherOutput.FigA2Alayout.y1Lim)
ylabel('Cash Flows', 'Rotation',90)
stem([CFsX0(:,1) CFsX0(:,2)])
yyaxis right
ylim(otherOutput.FigA2Alayout.y2Lim)
yticks(otherOutput.FigA2Alayout.y2Ticks)
ylabel('Asset Value', 'Rotation',90)
plot(Values(:,1),'r+','MarkerSize',6,'MarkerFaceColor','r')
plot(Values(:,end),'k-')
xlabel('week since inception', 'Rotation',0)
legend('Capital Calls (=C)','Distributions (=D)','Reported NAVs (=N)','True Asset Values (=V)',...
        'Location','northeast','Orientation','vertical','FontSize',strSize)
        legend('boxoff')
xlim(xLim)
xticks(xTic)        
hold off
if replaceFig==1
    print(char(strcat(figPathOut,'FigA2panA_',figNameIdx)),'-dpng','-r0')
    print(char(strcat(figPathOut,'FigA2panA_',figNameIdx)),'-dpdf','-r0','-bestfit')
end


figure
x0=560;y0=50;
width=800; height=width/otherOutput.FigA2Blayout.aspect;
set(gcf,'units','points','position',[x0,y0,width,height])
xLim=otherOutput.FigA2Blayout.xLim;
xTic=otherOutput.FigA2Blayout.xTic;
grid off
hold on
yyaxis left
gross_value=Values(:,end)+CFs(:,2);
ylim(otherOutput.FigA2Blayout.y1Lim)
ylabel('Cash Flows', 'Rotation',90)
stem([CFsX0(:,1)./gross_value CFsX0(:,2)./gross_value])
yyaxis right
ylim(otherOutput.FigA2Blayout.y2Lim)
yticks(otherOutput.FigA2Blayout.y2Ticks)
ylabel('Reported/Nowcasted NAV bias', 'Rotation',90)
plot(Values(:,1)./Values(:,end)-1,'r+','MarkerSize',6,'MarkerFaceColor','r')
plot(Values(:,2)./Values(:,end)-1,'r:')
xlabel('week since inception', 'Rotation',0)
legend('C/(V+D){            }','D/(V+D){                           }',...
        'N/V-1{         }','(Naive nowcasts)/V-1',...
        'Location','south','Orientation','horizontal','FontSize',strSize)
        legend('boxoff')
xlim(xLim)
xticks(xTic)          
hold off
if replaceFig==1
    print(char(strcat(figPathOut,'FigA2panB_',figNameIdx)),'-dpng','-r0')
    print(char(strcat(figPathOut,'FigA2panB_',figNameIdx)),'-dpdf','-r0','-bestfit')
end


%% Figure A3
figure
x0=560;y0=50;
width=800; height=width/otherOutput.FigA3Alayout.aspect;
set(gcf,'units','points','position',[x0,y0,width,height])
hold on 
X=prof_alpha_range*52*100;
Y=prof_beta_range;
Z=norm_LogProfile;
mesh(X,Y,Z,'edgecolor','k','FaceColor','none')
Z=norm_LogProfile2;
mesh(X,Y,Z,'edgecolor','b','FaceColor',[.93,.93,1])
xlabel('\alpha  (% p.a.)', 'Rotation',otherOutput.FigA3Alayout.alfaScaleAngle)
ylabel('\beta           ', 'Rotation',otherOutput.FigA3Alayout.betaScaleAngle)
zlabel('Norm. Llhood/Penalty Fn')
view(otherOutput.FigA3Alayout.angle(1),otherOutput.FigA3Alayout.angle(2))
legend('Likelihood maximized w.r.t remaining SSM parameters',...
       'Penalty function based on abs(PME(\alpha+\beta r_m)-1)',...
        'Location','northeast','Orientation','vertical','FontSize',strSize)
        legend('boxoff')
grid on
hold off
if replaceFig==1
    print(char(strcat(figPathOut,'FigA3panA_',figNameIdx)),'-dpng','-r0')
    print(char(strcat(figPathOut,'FigA3panA_',figNameIdx)),'-dpdf','-r0','-bestfit')
end

figure
x0=560;y0=50;
width=800; height=width/otherOutput.FigA3Blayout.aspect;
set(gcf,'units','points','position',[x0,y0,width,height])
hold on 
X=prof_alpha_range*52*100;
Y=prof_beta_range;
Z=penalLogProfile;
surface(X,Y,Z,'edgecolor','none')
% colormap(winter)
colormap(summer)
xlabel('\alpha  (% p.a.)', 'Rotation',otherOutput.FigA3Blayout.alfaScaleAngle)
ylabel('\beta           ', 'Rotation',otherOutput.FigA3Blayout.betaScaleAngle)

zlabel('Penalized Likelihood')
view(otherOutput.FigA3Blayout.angle(1),otherOutput.FigA3Blayout.angle(2))
xx=TrueAlpha*100;
yy=TrueBeta;
zz=otherOutput.FigA3Blayout.floor;
plot3(xx,yy,zz,'ro','MarkerSize',7,'MarkerFaceColor','r')
grid on
legend('Penalized SSM Likelihood','True parameters',...
        'Location','northeast','Orientation','vertical','FontSize',strSize)
        legend('boxoff')
hold off
if replaceFig==1
    print(char(strcat(figPathOut,'FigA3panB_',figNameIdx)),'-dpng','-r0')
    print(char(strcat(figPathOut,'FigA3panB_',figNameIdx)),'-dpdf','-r0','-bestfit')
end
%% Figure A4

non0cf=(nansum(CFs,2)~=0);
non0cf(1)=1;
figure
x0=560;y0=50;
width=800; height=width/otherOutput.FigA4Alayout.aspect;
set(gcf,'units','points','position',[x0,y0,width,height])
xLim=otherOutput.FigA4Alayout.xLim;
xTic=otherOutput.FigA4Alayout.xTic;
grid off
hold on
yyaxis left
ylim(otherOutput.FigA4Alayout.y1Lim)
yticks(otherOutput.FigA4Alayout.y1Ticks)
ylabel('log(Mapping)', 'Rotation',90)
stairs(tt(non0cf),log(Ms(non0cf,3)),'-k')
stairs(tt(non0cf),log(Ms(non0cf,1)),':sk','MarkerSize',4)
stairs(tt(non0cf),log(Ms(non0cf,2)),'-.dk','MarkerSize',4)
yyaxis right
ylim(otherOutput.FigA4Alayout.y2Lim)
yticks(otherOutput.FigA4Alayout.y2Ticks)
ylabel('Difference in log Returns', 'Rotation',90)
plot(tt,CumRets(:,2)-CumRets(:,end),'r:',...
     tt,CumRets(:,4)-CumRets(:,end),'r-','LineWidth', 1.1)
line(xlim, [0 0], 'LineWidth', 0.5, 'Color', 'k','LineStyle',':');
text(T0,-0.3,'\rightarrow Out-of-Sample')
line([T0 T0], ylim(), 'LineWidth', 0.5, 'Color', 'k','LineStyle',':');
xlabel('week since inception', 'Rotation',0)
legend(' True Asset-to-Value Mapping (AVM) ',...
        'Naive nowcast AVM', 'SSM-refined AVM',...
        'Cumulative Returns Error from Naive nowcasts ',...
        'Cumulative Return Error from SSM nowcasts',...
        'Location','northwest','Orientation','vertical','FontSize',strSize)
        legend('boxoff')
xticks(xTic)        
xlim(xLim)
ax = gca;
ax.XAxis.MinorTick = 'on';
ax.XAxis.MinorTickValues = tt(non0cf);
hold off
if replaceFig==1
    print(char(strcat(figPathOut,'FigA4panA_',figNameIdx)),'-dpng','-r0')
    print(char(strcat(figPathOut,'FigA4panA_',figNameIdx)),'-dpdf','-r0','-bestfit')
end


figure
x0=560;y0=50;
width=800; height=width/otherOutput.FigA4Blayout.aspect;
set(gcf,'units','points','position',[x0,y0,width,height])
xLim=otherOutput.FigA4Blayout.xLim;
xTic=otherOutput.FigA4Blayout.xTic;
xLine=otherOutput.FigA4Blayout.Xline;
grid off
hold on
yyaxis left
ylim(otherOutput.FigA4Blayout.y1Lim)
yticks(otherOutput.FigA4Blayout.y1Ticks)
ylabel('log Multiple', 'Rotation',90)
plot(tt,log(FundOutput.Details.PME_1toTT_rctVtruNAV),'k:',...
     tt,log(FundOutput.Details.PME_1toTT_SSMrtVtruNAV),'k-.')
yyaxis right
ylim(otherOutput.FigA4Blayout.y2Lim)
yticks(otherOutput.FigA4Blayout.y2Ticks)
ylabel('Root Mean Squared Error', 'Rotation',90)
plot(tt,QRMSEsMQ(:,1),'rd',tt,QRMSEsMQ(:,2),'r*')
text(T0,otherOutput.FigA4Blayout.TxtH,'\rightarrow Out-of-Sample')
line(xLim, [xLine xLine], 'LineWidth', 0.25, 'Color', 'k','LineStyle','-');
line([T0 T0], ylim(), 'LineWidth', 0.25, 'Color', 'k','LineStyle','-');
xlabel('week since inception', 'Rotation',0)
legend('PME(true NAVs, Comp returns)', 'PME(true NAVs, SSM returns)',...
       'RMSE(true NAVs, Naive nowcasts)','RMSE(true NAVs, SSM nowcasts)',... 
        'Location','northwest','Orientation','horizontal','NumColumns',2,'FontSize',strSize)
        legend('boxoff')
xticks(xTic)        
xlim(xLim)
ax = gca;
ax.XAxis.MinorTick = 'on';
ax.XAxis.MinorTickValues = tt(non0cf);
hold off
if replaceFig==1
    print(char(strcat(figPathOut,'FigA4panB_',figNameIdx)),'-dpng','-r0')
    print(char(strcat(figPathOut,'FigA4panB_',figNameIdx)),'-dpdf','-r0','-bestfit')
end
end
