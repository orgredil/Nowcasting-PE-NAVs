function figReplaced = FundOutputDrawFigs(FundOutput,otherOutput,figNameIdx,strSize,replaceFig,figPathOut)
%% this function depicts selected output from PEfundSSMlogCAPM.m for the hypothetical 
% case when true asset value of the fund were known.
% See Section 2 of the paper for discussion.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figReplaced=0;

dat=[(FundOutput.Details.periods_T0T4(1):FundOutput.Details.periods_T0T4(end))' ...
      FundOutput.Details.TrueVs_T0T4 ...
      FundOutput.Details.ssmRealTimeNAV_T0T4 ...
      FundOutput.Details.NaiveRealTime_T0T4 ...
      exp(otherOutput.yFund(FundOutput.Details.periods_T0T4(1):FundOutput.Details.periods_T0T4(end),2))  ...
      otherOutput.CFandVhatXt0(FundOutput.Details.periods_T0T4(1):FundOutput.Details.periods_T0T4(end),[2 3])];
dat(:,2:end)=dat(:,2:end)/dat(1,2); % normalize series to the NAV level on T0

tVs=FundOutput.Details.periods_T0T4(2:end-1)-FundOutput.Details.periods_T0T4(1)+2;
tDs=dat(dat(:,6)>0,1)-FundOutput.Details.periods_T0T4(1)+1;

ts=sort([tVs;tDs]);
% keyboard
%%
datTrue4c =[repmat(dat(:,2),1,length(ts)+1) ];
datSSM4c  =[repmat(dat(:,3),1,length(ts)+1) ];
datNaive4c=[repmat(dat(:,4),1,length(ts)+1) ];

datTrue4c(1:ts(end)-1,length(ts)+1) = nan;
datSSM4c(1:ts(end)-1,length(ts)+1) = nan;
datNaive4c(1:ts(end)-1,length(ts)+1) = nan;
for tt=1:length(ts)
    datNaive4c(ts(tt):end,tt)=nan;
    datSSM4c(ts(tt):end,tt)  =nan;
    datTrue4c(ts(tt):end,tt)  =nan;
    try
        tlag=ts(tt-1);
        datNaive4c(1:tlag-2,tt)=nan;
        datSSM4c(1:tlag-1,tt)  =nan;
        datTrue4c(1:tlag-1,tt)  =nan;
    catch
    end
    if ismember(ts(tt),tVs)==1
        datNaive4c(ts(tt)-1,tt+1)=dat(ts(tt)-1,5);
    end
    if ismember(ts(tt),tDs)==1
        datNaive4c(ts(tt)-1,tt+1)=nan;
        datNaive4c(ts(tt),tt)=datNaive4c(ts(tt),tt+1)+dat(ts(tt),6);
        datSSM4c(ts(tt),tt)  =datSSM4c(ts(tt),tt+1)+dat(ts(tt),6);
%         datTrue4c(ts(tt),tt) =datTrue4c(ts(tt),tt+1)+dat(ts(tt),6);
    end   
end    

datTrue  =[repmat(dat(:,2),1,length(tDs)+1) dat(:,6)];
for tt=1:length(tDs)
    datTrue(tDs(tt)+1:end,tt)=nan;
    try
        tlag=tDs(tt-1);
        datTrue(1:tlag-1,tt)=nan;
        datTrue(tlag,tt-1)=datTrue(tlag,tt-1)+dat(tlag,6);
    catch
    end
end    
datTrue(1:tDs(end)-1,length(tDs)+1) = nan;
datTrue(tDs(end),length(tDs))=datTrue(tDs(end),length(tDs))+dat(tDs(end),6);



close all
% naiErr=nansum(datNaive4c-datTrue4c,2);
% ssmErr=nansum(datSSM4c-datTrue4c,2);

% naiErr=nanmin(datNaive4c,[],2)./nanmax(datTrue4c,[],2)-1;
% ssmErr=nanmin(datSSM4c,[],2)./nanmax(datTrue4c,[],2)-1;
naiErr=datNaive4c./datTrue4c-1;
ssmErr=datSSM4c./datTrue4c-1;

%%
figure(1);
hold on
plot(dat(:,1),dat(:,5),'o','LineStyle','none','MarkerSize',10,'MarkerFaceColor','r');
bar(dat(:,1),dat(:,6),'r');
for sp=1:length(tDs)+1
    plot(dat(:,1),datTrue(:,sp),'b-','LineWidth',1.25);
end
legend('Reported NAVs','Distributions from Fund','True NAVs',...
       'Location','NorthEast','FontSize',strSize);
xlabel('week # from inception')
xlim([min(dat(:,1))-1 max(dat(:,1))+1])

hold off
if replaceFig==1
    print(char(strcat(figPathOut,'Fig1_VnObs_',figNameIdx)),'-dpng','-r0')
    print(char(strcat(figPathOut,'Fig1_VnObs_',figNameIdx)),'-dpdf','-r0')
end
%%
figure(2);
hold on
for sp=1:length(ts)+1
    plot(dat(:,1),datNaive4c(:,sp),'m-.','LineWidth',1.75);
end
plot(dat(:,1),dat(:,5),'o','LineStyle','none','MarkerSize',10,'MarkerFaceColor','r');
bar(dat(:,1),dat(:,6),'r');

legend('Naive nowcasts','Location','NorthEast','FontSize',strSize)
xlabel('week # from inception')
ylim([0 1.2])
xlim([min(dat(:,1))-1 max(dat(:,1))+1])

hold off

if replaceFig==1
    print(char(strcat(figPathOut,'Fig1_Naive_',figNameIdx)),'-dpng','-r0')
    print(char(strcat(figPathOut,'Fig1_Naive_',figNameIdx)),'-dpdf','-r0')
end
%%
figure(3);
hold on

for sp=1:length(ts)+1
    plot(dat(:,1),datSSM4c(:,sp),'k-.','LineWidth',1.75);
end
plot(dat(:,1),dat(:,5),'o','LineStyle','none','MarkerSize',10,'MarkerFaceColor','r');
bar(dat(:,1),dat(:,6),'r')

legend('SMM-based nowcasts','Location','NorthEast','FontSize',strSize)
ylim([0 1.2])
xlim([min(dat(:,1))-1 max(dat(:,1))+1])

xlabel('week # from inception')
hold off

if replaceFig==1
    print(char(strcat(figPathOut,'Fig1_SSM_',figNameIdx)),'-dpng','-r0')
    print(char(strcat(figPathOut,'Fig1_SSM_',figNameIdx)),'-dpdf','-r0')
end
%%
nav_dts = dat(:,1);
dis_dts = dat(:,1);
nav_dts(isnan(dat(:,5))) = [];
dis_dts(dat(:,6)==0) = [];

figure(4);
hold on
    h=stem(dat(:,1),[naiErr,ssmErr],'m-.','LineWidth',0.75);
    stem(dat(:,1),'k-.','LineWidth',0.75);
    for ii=1:size(ssmErr,2)
       h(ii+size(naiErr,2)).Color='black'; 
    end
    for sp=2:length(nav_dts)-1
        xline(nav_dts(sp),'r--','LineWidth',0.5);
    end
    for sp=1:length(dis_dts)-1
        xline(dis_dts(sp),'r-','LineWidth',0.5);
    end
xlabel('week # from inception')
ylim([0 1.6]-.8)
xlim([min(dat(:,1))-1 max(dat(:,1))+1])
yline(0);
legend([h(1); h(size(naiErr,2)+1)],'Naive nowcasts Error','SSM-based nowcasts Error','Location','NorthEast','FontSize',strSize)
hold off
if replaceFig==1
    print(char(strcat(figPathOut,'Fig1_2lineWlines_',figNameIdx)),'-dpng','-r0')
    print(char(strcat(figPathOut,'Fig1_2lineWlines_',figNameIdx)),'-dpdf','-r0')
end
%%
figure(5);
hold on
    h=stem(dat(:,1),[naiErr,ssmErr],'m-.','LineWidth',0.75);
    for ii=1:size(ssmErr,2)
       h(ii+size(naiErr,2)).Color='black'; 
    end
xlabel('week # from inception')
ylim([0 1.6]-.8)
xlim([min(dat(:,1))-1 max(dat(:,1))+1])
yline(0);
legend([h(1); h(size(naiErr,2)+1)],'Naive nowcasts Error','SSM-based nowcasts Error','Location','NorthEast','FontSize',strSize)
hold off

if replaceFig==1
    print(char(strcat(figPathOut,'Fig1_2lineClean_',figNameIdx)),'-dpng','-r0')
    print(char(strcat(figPathOut,'Fig1_2lineClean_',figNameIdx)),'-dpdf','-r0')
end
%%
disp('Figures Drawn')
figReplaced=replaceFig;
end