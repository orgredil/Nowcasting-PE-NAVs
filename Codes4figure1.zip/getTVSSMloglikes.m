function [LL,lli] = getTVSSMloglikes(Mdl,Y,params0,varargin)

%evaluate likelihood of indivudual obs for the time-varying SSM 
%
%
% Description:
%
%   For observation vector y(t) and state vector x(t), estimate parameters 
%   of the following general state-space model by maximum likelihood:
%
%   State equation:       x(t) = A(t) * x(t-1) + B(t) * u(t)
%   Observation equation: y(t) = C(t) * x(t)   + D(t) * e(t)
%
%   where u(t) and e(t) are uncorrelated, unit-variance white noise vector
%   processes. The length of x(t), y(t), u(t), and e(t) is m, n, k, and h, 
%   respectively.
%

%   For models created implicitly by specifying a parameter mapping function 
%   ParamMap, the mapping function is responsible for managing the presence 
%   and placement of unknown parameters. In the implicit approach, the mapping
%   function alone defines the model, and is particularly convenient for 
%   estimating complex models and for imposing certain parameter constraints. 
%   Moreover, in more general settings in which the initial states are also 
%   determined by unknown parameters, ParamMap may include additional output 
%   arguments; refer to the SSM/DSSM constructor for more details.
%
% Input Arguments:
%
%   Mdl - A state-space model with unknown parameters to estimate, created 
%     by the SSM/DSSM constructor.
%
%   Y - Observed response data to which the model is fit. For time-invariant 
%     models in which the length of each observation vector (n) is the same, 
%     Y is a T-by-n matrix. For time-varying models in which the length of 
%     the observation vector changes, Y is a T-by-1 cell array in which 
%     each element contains a time-varying n-element vector of observations, 
%     y(t), associated with the corresponding period. The last observation 
%     is the most recent.
%
%   params0 - A vector containing the initial values of unknown 
%     parameters associated with model coefficients A, B, C, and D, and 
%     optionally the mean vector (Mean0) and covariance matrix (Cov0) of 
%     initial states x(0), estimated by maximum likelihood. For models created 
%     explicitly, parameters mapped to NaN values are found by a column-wise 
%     search of A, followed by B, then C, then D, and finally Mean0 and Cov0. 
%     For models created implicitly, the parameter function ParamMap is 
%     solely responsible for mapping the initial parameter vector into model 
%     coefficients A, B, C, and D, as well as additional information 
%     regarding initial states and types if necessary. 
%
% Optional Input Name/Value Pairs:
%
%   'Univariate'  Logical value indicating whether to use the univariate 
%                 treatment of a multivariate series. The default is false.
%
%   'SquareRoot'  Logical value indicating whether to use the square-root 
%                 filter. The default is false.
%                 SSM only. No effects on DSSM.
%
%   'Tolerance'   A small, non-negative variance tolerance that controls 
%                 whether an observed series is ignored if its forecast
%                 uncertainty falls below this threshold. Setting tolerance 
%                 to a small number, say 1e-15, may help overcome numerical 
%                 problems of the filter. The default is 0.
%
%   'Predictors'  T-by-d matrix of common predictor variables used to
%                 include a regression component in the observation equation. 
%                 Observations at time t are deflated such that
%
%                 [y(t) - z(t)*b] = C * x(t) + D * e(t)
%
%                 where z(t) is a vector of predictor variables and b is 
%                 the regression coefficient vector (see below). The default
%                 is an empty matrix (no regression component)
%
%   'Beta0'       d-by-n matrix of initial values of regression coefficients 
%                 associated with predictors (see above). If the model contains
%                 a regression component, coefficients are estimated along 
%                 with other unknown parameters in A, B, C, D, Mean0, and 
%                 Cov0; the default initial values are obtained by ordinary 
%                 least squares (OLS) by regressing Y on the explanatory 
%                 variables.
%
%   'SwitchTime'  a positive integer that specifies the date after which the
%                 diffuse filter switches to the standard filter.
%                 The default is the earliest date when the smoothed
%                 initial states have a full-rank covariance matrix.
%                 DSSM only. No effects on SSM.
%
%   'CovMethod'   String or character vector indicating the method for
%                 computing the asymptotic parameter error covariance
%                 matrix of estimated parameters. Values are:
%
%                 VALUE             METHOD
%
%                 o 'hessian'       Negative inverted Hessian matrix
%                 o 'opg'           Outer product of gradients (default)
%                 o 'sandwich'      Both Hessian and outer product of gradients
%
%   'Options'     Optimization options created with OPTIMOPTIONS. If 
%                 specified, default optimization parameters are replaced 
%                 by those in options. The default OPTIMOPTIONS object depends
%                 on the optimization function used to estimate parameters.
%                 For constrained optimization, FMINCON is called and the 
%                 algorithm used is interior point; for unconstrained 
%                 optimization, FMINUNC is called and the algorithm is 
%                 quasi-Newton. See documentation for OPTIMOPTIONS, FMINCON, 
%                 and FMINUNC for details.
%
%   'Display'    String vector or cell vector of character vectors
%                indicating what information to display in the command
%                window. Values are:
%  
%                VALUE           DISPLAY
%  
%                o 'off'         No display to the command window. 
%  
%                o 'params'      Display maximum likelihood parameter 
%                                estimates, standard errors, and t statistics.
%                                This is the default.
%
%                o 'iter'        Display iterative optimization information.
%
%                o 'diagnostics' Display optimization diagnostics.
%
%                o 'full'        Display 'params', 'iter', and 'diagnostics'.            
%
%   The following optional name/value pairs are related to constrained
%   optimization performed by FMINCON (see FMINCON for details):
%
%   'Aineq'  Linear inequality matrix, such that for solution vector X 
%            Aineq*X <= bineq. The number of rows is determined by the 
%            number of constraints, and the number of columns by the number 
%            of estimated parameters. Columns are ordered by estimated 
%            parameters in A, B, C, D, Mean0, Cov0, and finally regression 
%            coefficients for models with a regression component.
%
%   'bineq'  Linear inequality column vector, such that for solution vector
%            X Aineq*X <= bineq. 
%
%   'Aeq'    Linear equality matrix, such that for solution vector X 
%            Aeq*X = beq. The number of rows is determined by the 
%            number of constraints, and the number of columns by the number 
%            of estimated parameters. Columns are ordered by estimated 
%            parameters in A, B, C, D, Mean0, Cov0, and finally regression 
%            coefficients for models with a regression component.
%
%   'beq'    Linear equality column vector, such that for solution vector X 
%            Aeq*X = beq. 
%
%   'lb'     Lower bounds column vector on estimated parameters. Vector 
%            elements are ordered by estimated parameters in A, B, C, D, 
%            Mean0, Cov0, and finally regression coefficients for models with 
%            a regression component.
%
%   'ub'     Upper bounds column vector on estimated parameters. Vector 
%            elements are ordered by estimated parameters in A, B, C, D, 
%            Mean0, Cov0, and finally regression coefficients for models with 
%            a regression component.
%
% Output Arguments:
%
%   EstMdl - A fitted state-space model with estimated model coefficients. 
%     Provided the optimization converged successfully, the model is explicit 
%     in its coefficients A, B, C, D, Mean0, and Cov0 regardless of whether 
%     the input model (Mdl) was created explicitly or implicitly.
%
%   estParams - Vector of estimated parameter. The elements are ordered such
%     that any estimated parameters in A appear first, then B, then C, then
%     D, and finally Mean0 and Cov0. Additionally, if the observation equation
%     includes a regression component, then estimates of any regression 
%     coefficients appear last.
%
%   EstParamCov - Variance-covariance matrix of estimated parameters. The
%     rows/columns are ordered such that variances/covariances of any 
%     estimated parameters in A appear first, then B, then C, then D, and 
%     finally Mean0 and Cov0. Additionally, if the observation equation
%     includes a regression component, then variances/covariances of any 
%     estimated regression coefficients appear last.
%
%   logL - Log-likelihood of the observations.
%
%   Output - Output structure with the following fields:
%
%      o ExitFlag - Optimization exit flag that describes the exit condition.
%          See FMINCON or FMINUNC for additional details.
%
%      o Options - Optimization options, created with OPTIMOPTIONS, and used
%          by the optimizer.
%
% Notes:
%
%   o Missing observations in Y are indicated by NaNs.
%
%   o Although creating a model explicitly by directly specifying parameters
%     (A, B, C, D, etc.) with NaN placeholders to indicate parameters to 
%     estimate is more convenient than specifying a user-defined mapping 
%     function ParamMap, the utility of an explicit approach is limited in 
%     that each estimated parameter affects and is uniquely associated with 
%     a single element of a coefficient matrix. 
%
%   o The option of univariate treatment requires a diagonal D(t)*D(t)'.
%
%   o The state-space model itself does not store regression data or 
%     coefficients. Instead, a regression component is used to deflate the 
%     observations, such that the deflated data is given by y(t) - z(t)*b. 
%
%   o Regression coefficients in the observation equation are estimated along 
%     with other unknown parameters, and so parameter constraints may be 
%     placed on regression coefficients as well other parameters by specifying 
%     appropriate entries in 'Aineq', 'bineq', etc.
%
%   o If observations are multivariate, then the same regressors apply to all.
%
%   o If the state equation requires predictors, or each individual component 
%     of the observation equation requires a set of distinct predictors, try
%     one of the following methods:
%
%       o Expand the states by a constant one.
%       o Expand the states by predictors.
%       o Return 8 output arguments from the user-supplied function 
%         ParamMap, the last of which is the deflated observation data.
%
%   o Regression components in the observation equation are allowed only for
%     time-invariant observations, in which the input observation series Y
%     is of constant length and specified as a T-by-n matrix. Y specified as
%     a T-by-1 cell array indicates a time-varying observation series whose 
%     length may change over time. If the length of each observation y(t)
%     changes, then it is unclear which regression coefficients are needed
%     to deflate a given observation.
%
%   o If no constraints are specified, FMINUNC is used; otherwise, FMINCON 
%     is used for constrained optimization. Therefore, when specifying the 
%     input Options, the input should be consistent with the solver (see 
%     OPTIMOPTIONS, FMINCON, and FMINUNC for details).
%
%     Whenever possible, it is recommended to avoid equality/inequality 
%     constraints by reparameterizing the model. For example, various 
%     parameters may be exponentiated using EXP to ensure positivity.
%
%   o The observations in the starting periods are treated as if they were
%     presample data for exact initialization of the diffuse initial
%     states. We define the likelihood function as the joint density
%     of the observations after the algorithm is switched to
%     the standard Kalman filter. The variable 'SwitchTime' determines when
%     the standard Kalman filter starts.
%  
% See also SSM, DSSM, FILTER, SMOOTH, FORECAST, SIMULATE, SIMSMOOTH.

% Copyright 2015 The MathWorks, Inc.

wstate = warning;
cleanUp = onCleanup(@()warning(wstate));
warning('off','econ:statespace:statespace:NotPSD')
warning('off','econ:statespace:statespace:NotSymmetry')

numDigits = 5;
alignment = 'decimal';
precaution = nargin > 1;
% precaution = false;

if nargin < 3
    error(message('econ:statespace:estimate:NotEnoughInputs'))
end

if ischar(params0) || isstring(params0)
    error(message('econ:statespace:estimate:NoStartingValues'))
end

isDiffuseMdl = isa(Mdl,'dssm');

% Parse inputs and set defaults
tolDefault = 0;
if isDiffuseMdl
    callerName = 'dssm.estimate';
else
    callerName = 'ssm.estimate';
end
parseObj = inputParser;
addParameter(parseObj,'Univariate',false,@(x)validateattributes(x,{'numeric','logical'},{'scalar','binary'},callerName));
addParameter(parseObj,'SquareRoot',false,@(x)validateattributes(x,{'numeric','logical'},{'scalar','binary'},callerName));
addParameter(parseObj,'Tolerance',tolDefault,@(x)validateattributes(x,{'numeric','logical'},{'scalar','nonnegative'},callerName));
addParameter(parseObj,'CovMethod','Opg',@(x)validateattributes(x,{'char','string'},{'scalartext'},callerName));
addParameter(parseObj,'Options',[],@(x)validateattributes(x,{'struct','optim.options.Fmincon','optim.options.Fminunc'},{},callerName));
addParameter(parseObj,'Aineq',[],@(x)validateattributes(x,{'numeric','logical'},{'2d','finite'},callerName));
addParameter(parseObj,'bineq',[],@(x)validateattributes(x,{'numeric','logical'},{'2d'},callerName));
addParameter(parseObj,'Aeq',[],@(x)validateattributes(x,{'numeric','logical'},{'2d','finite'},callerName));
addParameter(parseObj,'beq',[],@(x)validateattributes(x,{'numeric','logical'},{'2d'},callerName));
addParameter(parseObj,'lb',[],@(x)validateattributes(x,{'numeric','logical'},{'2d'},callerName));
addParameter(parseObj,'ub',[],@(x)validateattributes(x,{'numeric','logical'},{'2d'},callerName));
addParameter(parseObj,'Display',[]);
addParameter(parseObj,'Predictors',[],@(x)validateattributes(x,{'numeric','logical'},{'2d'},callerName));
addParameter(parseObj,'Beta0',[],@(x)validateattributes(x,{'numeric','logical'},{'2d','finite'},callerName));
addParameter(parseObj,'SwitchTime',Inf,@(x)validateattributes(x,{'numeric'},{'scalar','nonnegative'},callerName));
parse(parseObj,varargin{:});
unitFlag = parseObj.Results.Univariate;
tol = parseObj.Results.Tolerance;
covMethod = parseObj.Results.CovMethod;
options = parseObj.Results.Options;
conFlagAin = parseObj.Results.Aineq;
conFlagbin = parseObj.Results.bineq;
conFlagAeq = parseObj.Results.Aeq;
conFlagbeq = parseObj.Results.beq;
conFlaglb = parseObj.Results.lb;
conFlagub = parseObj.Results.ub;
displaySet = parseObj.Results.Display;
Predictors = parseObj.Results.Predictors;
Beta0 = parseObj.Results.Beta0;
if isDiffuseMdl
    switchTime = parseObj.Results.SwitchTime;
    sqrtFlag = false;
else
    switchTime = 0;
    sqrtFlag = parseObj.Results.SquareRoot;
end

covMethod = lower(char(covMethod));
displaySet = lower(displaySet);

if Mdl.CompleteFlag && isempty(Predictors)
    error(message('econ:statespace:estimate:NoParameters'))    
end

if islogical(params0)
    params0 = double(params0);
end

if islogical(tol)
    tol = double(tol);
end

if ~isinf(switchTime) && switchTime~=round(switchTime)
    error(message('econ:statespace:estimate:IntegerSwitchTime'))
end

if ~logical(sqrtFlag)
    sqrtFlag = logical(sqrtFlag);
end

if ~logical(unitFlag)
    unitFlag = logical(unitFlag);
end

% Check the number of parameters
npara = numel(params0);
validateattributes(params0,{'numeric'},{'2d','finite'},'','params0');

% Get A,B,C,D and Check errors. Evaluated at the starting parameter values
    [A,B,C,D,mean0,Cov0,stateType,ind] = getABCD(Mdl,params0);


funFlag = (1==0);
if funFlag    
    [A,B,C,D,mean0,Cov0,stateType,ind] = getABCD(Mdl,params0);    
    if ind == 8
        Yold = Y;
        [A,B,C,D,mean0,Cov0,stateType,Y] = Mdl.PrivateParamMap(params0);
        if ~isempty(Yold) && (size(Y,1) ~= size(Yold,1))
            warning(message('econ:statespace:estimate:UnmatchedDeflateData'))
        end
    end          
else
    [A,B,C,D,mean0,Cov0,stateType,ind] = getABCD(Mdl,params0);
    timeVarying = ~isinf(Mdl.NumObsMax);
    timeVarying = (1~=0);
    
    % Time-varying model
    if timeVarying && (length(ind) ~= npara)
        % This error occurs when the length of params0 is different
        % from the searched quantity of NaNs in A,B,C,D
%         error(message('econ:statespace:estimate:UnmatchedParameters',length(ind),npara))
    end
    
    % Time-invariant model
    if ~timeVarying && (ind(end) ~= npara)
        % Barely accept regressor coefficients in params0. Otherwise, throw error
        if ~isempty(Predictors) && isempty(Beta0) && ~iscell(Y) && npara == ind(end)+size(Predictors,2)*size(Y,2)
            Beta0 = params0(ind(end)+1:end);
            params0 = params0(1:ind(end));
            npara = ind(end);
            % This warning occurs when regression starting values are
            % combined with params0
            warning(message('econ:statespace:estimate:SeparateParams'))
        else
            % This error occurs when the length of params0 is different
            % from the searched quantity of NaNs in A,B,C,D
            error(message('econ:statespace:estimate:UnmatchedParameters',ind(end),npara))
        end             
    end
        
end

% Check and fix coefficients 
% Write nobsMax,numStates,numSeries properties back to the model
if precaution
    [A,B,C,D,mean0,Cov0,stateType,~,nobsMax,numStates,numSeries] = statespace.fixcoeff(A,B,C,D,mean0,Cov0,stateType);
else
    Aold = A; Bold = B; Cold = C; Dold = D; mean0old = mean0; Cov0old = Cov0;
    [A,B,C,D,mean0,Cov0,stateType,~,nobsMax,numStates,numSeries] = statespace.fixcoeff(A,B,C,D,mean0,Cov0,stateType);
    if ~isequal(A,Aold) || ~isequal(B,Bold) || ~isequal(C,Cold) || ~isequal(D,Dold)...
            || ~isequal(mean0,mean0old) || ~isequal(Cov0,Cov0old)
        error(message('econ:statespace:estimate:PrecautionCheck'))        
    end
end
if funFlag
    Mdl.NumObsMax = nobsMax;
    Mdl.NumStates = numStates;
    Mdl.NumSeries = numSeries;
end
timeInvariant = ~iscell(A) && ~iscell(B) && ~iscell(C) && ~iscell(D);    

% Analyze state type, and write this property back to the model
if isempty(mean0) || isempty(Cov0)    
    [mean0,Cov0,stateType] = statespace.genstate(A,B,C,stateType,mean0,Cov0);
    Mdl.PrivateStateType = stateType;
    if ~isDiffuseMdl
        Cov0(isinf(Cov0)) = 1e7;
    end
end

% Make sure that diffuse states are represented by StateType == 2
if isDiffuseMdl    
    stateType = dssm.fillStateType(Cov0, stateType);
    Mdl.PrivateStateType = stateType;
    
    % Assign Inf to large variances, invert Cov0 to obtain Precision0
    Precision0 = dssm.infCov0(Cov0);
end

% Check PSD of the covariance matrix
if ~isDiffuseMdl && sqrtFlag
    if ~isempty(Cov0) && size(cholcov(Cov0)',1) == 0
        error(message('econ:statespace:estimate:Cov0NotPSD'))
    end
end

% Check and regulate data
Y = statespace.fixdata(Y,A,B,C,D);

if iscell(Y)
    nobs = length(Y);
else
    nobs = size(Y,1);
end

% Check 3D coefficient length
statespace.check3Dcoeff(A,B,C,D,nobs);

% Check switchTime
if isDiffuseMdl
    switchTime = dssm.checkSwitchTime(switchTime,stateType,Y);
end

% Handle regressors in the time-invariant model
% Only matrix form Y can be deflated by regressors
nRegParams = 0;
if ~isempty(Predictors)
    
    % This error occurs when data have time-varying length, thus cell array
    if iscell(Y)
        error(message('econ:statespace:estimate:UnsupportedRegressors'))
    end
            
    nSeries = size(Y,2);    
    [nobsCheck,nreg] = size(Predictors);
    nRegParams = nreg * nSeries;
    
    % This error occurs when regressors have different sample size
    if nobsCheck ~= nobs
        error(message('econ:statespace:estimate:MismatchedRegressors'))
    end        
    
    if ~isempty(Beta0)
        
        % This error occurs when user-supplied starting value of regression
        % parameters have wrong sizes
        if numel(Beta0) ~= nRegParams
            error(message('econ:statespace:estimate:MismatchedBeta0',nSeries,nreg,nRegParams))
        end
    else
        % Generate some starting values for Beta0 based on OLS
        fullData = all(~isnan([Y,Predictors]),2);
        PredictorsUse = Predictors(fullData,:);
        Yuse = Y(fullData,:);
        constOne = all(PredictorsUse==1);
        PredictorsExpand = [PredictorsUse,ones(size(PredictorsUse,1),1)];
        if any(constOne) || rank(PredictorsExpand) == nreg
            Beta0 = PredictorsUse \ Yuse;
        else
            Beta0 = PredictorsExpand \ Yuse;
            Beta0 = Beta0(1:end-1,:);
        end
        Beta0(~isfinite(Beta0)) = 0.1;
    end
end

% Concatenate unknown parameters with regression coefficients
if ~isempty(Predictors)
    if size(params0,1) == 1 && ~isscalar(params0)
        params0Big = [params0,Beta0(:)'];
    else
        params0Big = [params0(:);Beta0(:)];
    end
else
    params0Big = params0;
end

% Time-invariant SSM with mex files. Regulate Y as a T-by-n matrix
% mex file will be invoked only if these conditions are met:
% 1. A,B,C,D are not time varying.
% 2. Select univariate treatment and non-sqrt filter
% 3. Low dimension system
if timeInvariant && unitFlag && ~sqrtFlag ...
        && numStates(1)<100 && numSeries(1)<100 && (switchTime ~= nobs)    
    mexFlag = 1;
    if iscell(Y)        
        Y = cell2mat(Y);
    end
else
    mexFlag = 0;
end

% Check time-invariant univariate treatment requirement.
% If D'*D is not diagonal, states will be expanded.
% The expanded model has the same likelihood function as the old one.
% Repair will be done in the function fML
if timeInvariant && unitFlag && ~statespace.isDiag(D)    
    warning(message('econ:statespace:estimate:NotDiagonalRepair'))
end

% Check time-varying univariate treatment requirement
% States of a time-varying model cannot be combined automatically
% hence an error
if ~timeInvariant && unitFlag && ~statespace.isDiag(D)
    error(message('econ:statespace:estimate:NotDiagonal')) 
end


% Run Diffuse Kalman filter to obtain the actual switchTime
% In fML, switchTime is fixed among function evaluations
if isDiffuseMdl && isinf(switchTime)
    if ~isempty(Predictors)
        Ydeflate = statespace.deflateData(Y,Predictors,Beta0);
    else
        Ydeflate = Y;
    end
    partialFlag = true;
    [A,B,C,D] = statespace.array2cell(A,B,C,D);
    [~,~,SwitchProfile] = dssm.kalman(Ydeflate,A,B,C,D,mean0,Precision0, ...
        stateType,unitFlag,tol,switchTime,partialFlag);    
    switchTime = SwitchProfile.switchTime;
    if SwitchProfile.switchTime == nobs
        warning(message('econ:statespace:estimate:ImproperSmoothedX0'))
    end
end

% Generate a function handle for repeated evaluation
% fNegML = @(c)-fML(c,Mdl,Y,Predictors,unitFlag,sqrtFlag,mexFlag,mexTvFlag,tol,ind,switchTime,precaution);
% flogLvec = @(c)fMLgrad(c,Mdl,Y,Predictors,unitFlag,sqrtFlag,mexFlag,mexTvFlag,tol,ind,switchTime,precaution);

[LL,lli] = fML(params0Big,Mdl,Y,Predictors,unitFlag,sqrtFlag,0,0,tol,ind,switchTime,precaution);
% keyboard
end

%-------------------------------------------------------------------------
% Subfunction:
% Fill parameters into coefficient matrixes, 
% and then call Kalman filter to obtain the likelihood
function [logLikeSum,logL] = fML(c,Mdl,Y,Predictors,unitFlag,sqrtFlag,mexFlag,mexTvFlag,tol,ind,switchTime,precaution)

isDiffuseMdl = isa(Mdl,'dssm');

% Allocate parameters
if ~isempty(Predictors)
    numSeries = size(Y,2);
    nreg = size(Predictors,2);
    nRegParams = nreg * numSeries; 
    params = c(1:end-nRegParams);
    RegParams = zeros(nreg,numSeries);
    RegParams(:) = c(end-nRegParams+1:end);
else
    params = c;
end

% Fetch parameters of the model
% if Mdl.Is_Function_Set && ind == 8
%     % In this case, Y still need to be regulated before use    
%     [A,B,C,D,mean0,Cov0,stateType,Y] = Mdl.PrivateParamMap(params);
%     if iscell(Y) || isa(Y,'dataset') || isa(Y,'table')
%         if precaution
%             [A,B,C,D,mean0,Cov0] = statespace.fixcoeff(A,B,C,D,mean0,Cov0,stateType,0,Mdl.NumObsMax,Mdl.NumStates,Mdl.NumSeries);
%             Y = statespace.fixdata(Y,A,B,C,D);
%         end
%         if mexFlag && iscell(Y)
%             Y = cell2mat(Y);
%         end
%     end        
% else
    [A,B,C,D,mean0,Cov0] = getABCD(Mdl,params,ind);
% end

% Load stored stateType
% stateType = Mdl.PrivateStateType;
stateType = [0 0 0 0 1];
% Time-varying or not
iscellA = iscell(A);
iscellB = iscell(B);
iscellC = iscell(C);
iscellD = iscell(D);
iscellY = iscell(Y);

if iscellY
    nobs = length(Y);
else
    nobs = size(Y,1);
end

% Deflate the data
if ~isempty(Predictors)
    Y = Y - Predictors * RegParams;
end

% Initialize likelihood
% logL vector cannot be set all -Inf due to the diffuse case
logLikeSum = - Inf;
logL = zeros(nobs,1);

% If input matrices are not finite and real, return logL with -Inf
% This is different from error checking, because when A,B,C,D are not
% finite, it might be caused by a bad parameter value. So another value
% should be tried instead of an error message.
if precaution
    
    if iscellA
        for t = 1:nobs
            At = A{t};
            if ~all(isfinite(At(:))) || ~isreal(At)
                return
            end
        end
    else
        if ~all(isfinite(A(:))) || ~isreal(A)
            return
        end
    end
    
    if iscellB
        for t = 1:nobs
            Bt = B{t};
            if ~all(isfinite(Bt(:))) || ~isreal(Bt)
                return
            end
        end
    else
        if ~all(isfinite(B(:))) || ~isreal(B)
            return
        end
    end
    
    if iscellC
        for t = 1:nobs
            Ct = C{t};
            if ~all(isfinite(Ct(:))) || ~isreal(Ct)
                return
            end
        end
    else
        if ~all(isfinite(C(:))) || ~isreal(C)
            return
        end
    end
    
    if iscellD
        for t = 1:nobs
            Dt = D{t};
            if ~all(isfinite(Dt(:))) || ~isreal(Dt)
                return
            end
        end
    else
        if ~all(isfinite(D(:))) || ~isreal(D)
            return
        end
    end
    
end

% Regulate empty and scalar coefficient matrices
if precaution
    [A,B,C,D,mean0,Cov0] = statespace.fixcoeff(A,B,C,D,mean0,Cov0,stateType,0,Mdl.NumObsMax,Mdl.NumStates,Mdl.NumSeries);
end

% Handle initial distribution, the stateType has been prepared before
if isempty(mean0) || isempty(Cov0)      
    [mean0,Cov0] = statespace.genstate(A,B,C,stateType,mean0,Cov0);
    if isDiffuseMdl        
        % During parameter searches in MLE, stationary states may have a large
        % AR coefficient and the stationary distribution cannot be generated.
        % This additional protection could make DSSM estimation results
        % slightly different from SSM even if there are no diffuse states
        %
        mask1 = isinf(diag(Cov0));
        mask2 = stateType == 2;
        if any(mask1 ~= mask2)
            return
        end
        %}
    end
end

% For ssm, the generated or user-supplied function returned Cov0 may
% contain Inf diagonals. Replace it by 1e7
if ~isDiffuseMdl
    Cov0(isinf(Cov0)) = 1e7;
end

% Univariate treatment require D*D' diagonal. Expand states
if unitFlag && ~statespace.isDiag(D)
    [A,B,C,D,mean0,Cov0,stateType] = statespace.stateExpand(A,B,C,D,mean0,Cov0,stateType);
end

if isDiffuseMdl
    % Invert Cov0 to obtain Precision0
    Precision0 = dssm.infCov0(Cov0,false);
end

% Force symmetry
Cov0 = 0.5 * (Cov0 + Cov0');

% Call the core Kalman filter algorithm
% If the mex file fails, it will use MATLAB codes instead.
if mexFlag
       
    % C program requires double inputs
    if ~isa(Y,'double');Y = double(Y); end
    if ~isa(A,'double');A = double(A); end
    if ~isa(B,'double');B = double(B); end
    if ~isa(C,'double');C = double(C); end
    if ~isa(D,'double');D = double(D); end
    if ~isa(mean0,'double');mean0 = double(mean0); end
    if ~isa(Cov0,'double');Cov0 = double(Cov0); end
    if ~isa(tol,'double');tol = double(tol); end
    
    % C program requires full matrixes
    if issparse(Y); Y = full(Y); end
    if issparse(A); A = full(A); end
    if issparse(B); B = full(B); end
    if issparse(C); C = full(C); end
    if issparse(D); D = full(D); end
    
    % Dimension check before applying the mex file
    nstate = size(A,1);
    numSeries = size(C,1);
    if (size(A,2) ~= nstate) || (size(B,1) ~=nstate) || (size(C,2) ~= nstate) ...
            || (size(mean0,1) ~= nstate) || any(size(Cov0) ~= nstate) ...
            || (size(Y,2) ~= numSeries) || (size(D,1) ~= numSeries)
        % This error occurs in the unlikely event that dimension of
        % A,B,C,D suddenly change when a new parameter is tried.
        % but if it happens, MATLAB may crash without this check
        error(message('econ:statespace:estimate:SuddenDimChange'))
    end
    
    % Mex file
    try
        if ~isDiffuseMdl
            logL = internal.econ.kfcMex(Y,A,B,C,D,mean0,Cov0,tol);
        else
            % logL = internal.econ.dkfMex(Y,A,B,C,D,mean0,Precision0,tol,switchTime);
            [A,B,C,D] = statespace.array2cell(A,B,C,D);
            partialFlag = false;
            logL = dssm.kalman(Y,A,B,C,D,mean0,Precision0,stateType,unitFlag,tol,switchTime,partialFlag);
        end
    catch
        mexFlag = false;
    end  
    
end
% keyboard
% For ktv SSM
if ~isDiffuseMdl && mexTvFlag
    try
        logL = internal.econ.ktvMex(Y,A,B,C,D,mean0,Cov0,tol);
    catch
        mexTvFlag = false;
    end
end

% This is the Kalman filter in the MATLAB environment
if ~mexFlag && ~mexTvFlag
    
    [A,B,C,D] = statespace.array2cell(A,B,C,D);
    partialFlag = false;
    
    if ~isDiffuseMdl
        logL = ssm.kalman(Y,A,B,C,D,mean0,Cov0,unitFlag,sqrtFlag,tol);
    elseif switchTime == nobs
        % Diffuse likelihood
        logL = dssm.kalman(Y,A,B,C,D,mean0,Precision0,stateType,unitFlag,tol,switchTime,partialFlag);
        logLikeSum = logL(end);        
        if nargout > 1
            % Approximation to the vector-form logL in the prediction error
            % decomposition form for OPG etc.
            logLold = logL;
            logL = dssm.kalman(Y,A,B,C,D,mean0,Precision0,stateType,unitFlag,tol,Inf,partialFlag);
            if all(logL==0) && isfinite(logLikeSum)
                % The case where the initial state is properly initialized
                % in the last period, and only diffuse likelihood works                
                logL = logLold;                
            end
        end
        return
    else
        % Run the diffuse Kalman filter for exact initialization of the states        
        logL = dssm.kalman(Y,A,B,C,D,mean0,Precision0,stateType,unitFlag,tol,switchTime,partialFlag);
    end
end


% Sum up the log likelihood
logLikeSum = sum(logL(isfinite(logL)));
if logLikeSum == 0
    logLikeSum = -Inf;
    logL = -Inf(nobs,1);
end

% Optimization package requires objective function of double data type
if isa(logLikeSum,'single')
    logLikeSum = double(logLikeSum);
end


end


%-------------------------------------------------------------------------
% Subfunction:
% extract the second output of fML
function logL = fMLgrad(c,Mdl,Y,Regressors,unitFlag,sqrtFlag,mexFlag,mexTvFlag,tol,ind,switchTime,precaution)
[~,logL] = fML(c,Mdl,Y,Regressors,unitFlag,sqrtFlag,mexFlag,mexTvFlag,tol,ind,switchTime,precaution);
if all(logL == 0)
    logL(:) = -Inf;
end
end

