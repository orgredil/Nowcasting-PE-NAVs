clc
clear
close all

PathOut='.\Output\'; % output subfolder
replaceFig=1; % 0 if just drawing or 1 if want to (re)create the figure in .png and .pdf
replaceTab=1; % 0 or 1 if want to replace EstimationSummary.xlsx
strSize=11; % font size in the figures

CaseNum=0; % A hypothetical fund featured in Figure 1 of the paper:
           % true beta [alpha] are 1.1905 [0.0000], lamnda [sigma_n] are 0.900 [0.050]
           % idiosyncratic ret of Comp. Asset, comprise 40% of that of the fund   

feedTrueBeta =0; % 0 if the systematic risk of the fund needs be estimated, 1 if fixed to a desired level
feedBetterMap=0; % 0 the return-to-value mapping computed from naive nowcasts, 1 if less noisy

AppendixToo =1; % 0 if only main text figures, 1 if redrawing A2--A3 too  

%% Prepare data for estimation
figNameIdx=strcat('Case',num2str(CaseNum)); %suffix to figure names if saved

%Observed fund data
%weekly logs of distributions and reported NAVs (NaN for missing or zero) 
yFund=importdata(char(strcat('Case',num2str(CaseNum),'_yFund.csv')));

Cs  = importdata(char(strcat('Case',num2str(CaseNum),'_Cs.csv'))); %full capital calls schedule 
Ds  = importdata(char(strcat('Case',num2str(CaseNum),'_Ds.csv'))); %full distributions schedule

%initial estimate of weekly NAVs (e.g. via the Naive method) which implies a value-to-return mapping function 
NAV0 = importdata(char(strcat('Case',num2str(CaseNum),'_NAVweeklyEst.csv'))); 

otherInput=[]; % structure needed for the estimation function PEfundSSMlogCAPM.m to proceed
otherInput.Params0=[]; % use the by-default starting values
otherInput.Params0.lambdaFnPreset=[]; % ... and smoothing function


otherInput.UpdateMapping=1; %recursively update Return-Asset Mapping function
otherInput.ComputeSE=1; %numerically estimate SEs
otherInput.arithmetCAPM=1; % adjust the log return intercept for variance

otherInput.CFandVhat = [Cs Ds NAV0];

otherInput.rmt = importdata(char(strcat('Case',num2str(CaseNum),'_rmt.csv'))); %market log returns
otherInput.rct = importdata(char(strcat('Case',num2str(CaseNum),'_rct.csv'))); %comp asset log returns
otherInput.sqrt_ht = importdata(char(strcat('Case',num2str(CaseNum),'_sqrt_ht.csv'))); % idVol factor estimate

%upload unobserved fund data (for comparison)
otherInput.Params0.TrueVs = importdata(char(strcat('Case',num2str(CaseNum),'_true_Vt.csv')));

if feedTrueBeta==1
   otherInput.Params0.priorBet=[1.19 0.001]; % the second parameter is the SD allowed from the first 
end
   M0   = importdata(char(strcat('Case',num2str(CaseNum),'_InitialMapping.csv')));
if feedBetterMap==1
   otherInput.Mt = M0;  otherInput.UpdateMapping=0; %fix the asset-to-value mapping to the true one
end

%% Estimate SSM parameters and produce nowcasts
[FundOutput,otherOutput,~] = PEfundSSM(yFund,otherInput);
if replaceTab==1 
    delete(fullfile(PathOut,'EstimationSummary.xlsx'));
    sheetNumber=1;
    writetable(FundOutput.Horizons,strcat(PathOut,'EstimationSummary.xlsx'),'Sheet',sheetNumber,'Range','A1','WriteRowNames',true)
    writetable(FundOutput.RT_nowcastQuarters,strcat(PathOut,'EstimationSummary.xlsx'),'Sheet',sheetNumber,'Range','A8','WriteRowNames',true)
    writetable(FundOutput.ParameterEstimates,strcat(PathOut,'EstimationSummary.xlsx'),'Sheet',sheetNumber,'Range','A11','WriteRowNames',true)
    writetable(FundOutput.NowcastErrs_at1QafterParEst,strcat(PathOut,'EstimationSummary.xlsx'),'Sheet',sheetNumber,'Range','A15','WriteRowNames',true)
    writetable(FundOutput.WeeklyReturnNowcastProperties,strcat(PathOut,'EstimationSummary.xlsx'),'Sheet',sheetNumber,'Range','A22','WriteRowNames',true)
    writetable(FundOutput.NAVnowcastVtrueT0toT4,strcat(PathOut,'EstimationSummary.xlsx'),'Sheet',sheetNumber,'Range','A27','WriteRowNames',true)
end

%% Draw Figure 1 from the main text

fig1Replaced = FundOutputDrawFigs(FundOutput,otherOutput,figNameIdx,strSize,replaceFig,PathOut);

%% Draw Figures A2--A4
if AppendixToo==1
    %additional input for drawing
    otherOutput.TrueM=M0;
    otherOutput.TrueBeta=1.19;
    otherOutput.TrueAlfa=0.0468; %annualized
    
    otherOutput.FigA2Alayout=[];
    otherOutput.FigA2Alayout.aspect=2.5;
    otherOutput.FigA2Alayout.xLim=[1 575];
    otherOutput.FigA2Alayout.xTic=[1 52 104 156 208 260 312 364 428 520 562];
    otherOutput.FigA2Alayout.y1Lim=[-0.4 0.8];
    otherOutput.FigA2Alayout.y2Lim=[-0.25 10.5];
    otherOutput.FigA2Alayout.y2Ticks=[0 3 6 9 ];
    
    otherOutput.FigA2Blayout=[];
    otherOutput.FigA2Blayout.aspect=2;
    otherOutput.FigA2Blayout.xLim=[1 575];
    otherOutput.FigA2Blayout.xTic=[1 52 104 156 208 260 312 364 428 520 562];
    otherOutput.FigA2Blayout.y1Lim=[-0.5 0.5];
    otherOutput.FigA2Blayout.y2Lim=[-0.5 0.5];
    otherOutput.FigA2Blayout.y2Ticks=[-0.5 -0.25 0 0.25 0.5];
    
    otherOutput.FigA3Alayout=[];
    otherOutput.FigA3Alayout.aspect=1.5;
    otherOutput.FigA3Alayout.angle=[-65.5 45];
    otherOutput.FigA3Alayout.alfaScaleAngle=50;
    otherOutput.FigA3Alayout.betaScaleAngle=5;
    
    otherOutput.FigA3Blayout=[];
    otherOutput.FigA3Blayout.aspect=1.5;
    otherOutput.FigA3Blayout.angle=[-35.5 45];
    otherOutput.FigA3Blayout.floor=-10;
    otherOutput.FigA3Blayout.alfaScaleAngle=15;
    otherOutput.FigA3Blayout.betaScaleAngle=0;
    
    otherOutput.FigA4Alayout=[];
    otherOutput.FigA4Alayout.aspect=2;
    otherOutput.FigA4Alayout.xLim=[1 575];
    otherOutput.FigA4Alayout.xTic=[1 52 104 156 208 260 312 364 428 520 562];
    otherOutput.FigA4Alayout.y1Lim=[-2 5.1];
    otherOutput.FigA4Alayout.y1Ticks=-2:1:5;
    otherOutput.FigA4Alayout.y2Lim=[-.4 1.02];
    otherOutput.FigA4Alayout.y2Ticks=-0.4:0.2:1;
    
    otherOutput.FigA4Blayout=[];
    otherOutput.FigA4Blayout.aspect=2;
    otherOutput.FigA4Blayout.xLim=[1 575];
    otherOutput.FigA4Blayout.xTic=[1 52 104 156 208 260 312 364 428 520 562];
    otherOutput.FigA4Blayout.y1Lim=[-0.5 1];
    otherOutput.FigA4Blayout.y1Ticks=-1:0.25:1;
    otherOutput.FigA4Blayout.y2Lim=[0 1.8];
    otherOutput.FigA4Blayout.y2Ticks=0:0.3:1.8;
    otherOutput.FigA4Blayout.TxtH =1.6;
    otherOutput.FigA4Blayout.Xline=0.6;
    
    [figA234Replaced, feasibleOLSest] = FiguresA2toA4(FundOutput,otherOutput,figNameIdx,strSize,replaceFig,PathOut);
end